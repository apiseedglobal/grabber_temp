from bs4 import BeautifulSoup
import requests, os, json, sys
import stat

books : dict[str, int] = dict()
with open('./books.json', 'r') as _f :
    books = json.load(fp=_f)
 
book = chapter = None
list_of_temp : list[str] = []

def delete_json_files_in_temp2():
    folder = './temp2'
    if not os.path.exists(folder):
        return

    for filename in os.listdir(folder):
        if filename.endswith('.json'):
            file_path = os.path.join(folder, filename)
            try:
                os.chmod(file_path, stat.S_IWRITE)
                os.remove(file_path)
            except Exception as e:
                return

def resize_the_loader(current_book: str, current_chapter: int, total_chapter: int, books_dict: dict[str, int]):
    """
    Reduces the book's chapter count or removes it if fully processed,
    then rewrites books.json with the updated dictionary.
    """

    if current_chapter >= total_chapter:
        books_dict.pop(current_book, None)
    else:
        books_dict[current_book] = total_chapter - current_chapter

    with open('./books.json', 'w') as f:
        json.dump(books_dict, fp=f, indent=2)

class col:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    VIOLET = '\033[95m'   # Bright Magenta (closest)
    INDIGO = '\033[94m'   # Bright Blue
    BLUE   = '\033[34m'   # Standard Blue
    GREEN  = '\033[32m'   # Standard Green
    YELLOW = '\033[33m'   # Standard Yellow
    ORANGE = '\033[91m'   # Bright Red (closest ANSI match to orange)
    RED    = '\033[31m'   # Standard Red

def error_log(log : str) :
    if not os.path.isfile('./run2.log') :
        f = open('./run2.log', 'w')
        f.close()
    
    with open ('./run2.log', 'a') as f :
        f.write(log)


def extract_comm_data(url : str):
    parser = requests.get(url)
    html = parser.text
    soup = BeautifulSoup(html, 'html.parser')
    result = {}

    for comm in soup.select('.comm'):
        title_div = comm.find('div', class_='ttl')
        if title_div:
            key = title_div.text.strip()
            value = title_div.find_next_sibling(string=True)
            if value:
                result[key] = value.strip()

        for p in comm.find_all('p'):
            span = p.find('span', class_='Text_Heading')
            if span:
                key = span.text.strip()
                span.extract()
                value = p.text.strip()
                result[key] = value

    return result

def save(key : str, data : dict) :
    try :
        with open(f'./temp2/{key}.json', 'w', encoding='utf-8') as f :
            json.dump({key : data}, fp=f)
        list_of_temp.append(f'./temp2/{key}.json')
        return True
    except Exception as e :
        error_log(f'[-] Error : {e} for {book}.{chapter} with data : {data}')

def rebuild(book_ : str) :
    data : dict = dict()
    try :
        ct = 1
        lt = len(list_of_temp)
        for file in list_of_temp :
            print (f'{col.BLUE}{col.BOLD}[Rebuilding Data for {book_}]{col.ENDC} {col.GREEN}{round(ct / lt * 100, 1)}%...{col.ENDC}')
            ct = ct + 1
            with open(file, 'r', encoding='utf-8') as f :
                data = data | json.load(f)
        with open(f'./out2/{book_}.json', 'w') as file :
            json.dump(data, fp=file)
    except Exception as e :
        error_log(f'[-] Error : {e} re-writing for {book_}')

    delete_json_files_in_temp2()
    list_of_temp.clear()

    
count : int = 1
URL : str = 'https://biblehub.com/commentaries/illustrator/{}/{}.htm'
os.system('cls' if os.name == 'nt' else 'clear')
ln = len(books)
for book, chapter in books.items() :
    for i in range(1, chapter + 1) :
        URX = URL.format(book.lower(), str(i))
        per = round(round(count / ln * 100, 3) + round(i / chapter * 10, 4), 1)
        if 0 <= per <= 25:
            print (f'({col.FAIL}{per}%{col.ENDC}) {count}/{ln} - [{URX}]')
        elif 26 <= per <= 50:
            print (f'({col.YELLOW}{per}%{col.ENDC}) {count}/{ln} - [{URX}]')
        elif 51 <= per <= 75:
            print (f'({col.BLUE}{per}%{col.ENDC}) {count}/{ln} - [{URX}]')
        elif 76 <= per <= 100:
            print (f'({per}%) {book.upper()}')
        else:
            print("Number is out of range")
        print (f'{col.OKGREEN}[+]{col.ENDC} Working for {col.BLUE}{book}{col.ENDC} -> {col.OKCYAN}{round(i / chapter * 100, 2)}%{col.ENDC} ({i}/{chapter})')
        save(str(i), extract_comm_data(url=URX))
        resize_the_loader(current_book=book, current_chapter=i, total_chapter=chapter, books_dict=books)
        os.system('cls' if os.name == 'nt' else 'clear')
    count = count + 1
    rebuild(book_=book)
    os.system('cls' if os.name == 'nt' else 'clear')
    