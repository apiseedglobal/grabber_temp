import os, json, sys, stat
try :
    from bs4 import BeautifulSoup,  NavigableString
    import requests
except ImportError as e :
    print ('[!] it is observed that libraries are missing (connect to internet and press enter)')
    input('Are you connected ?')
    input('Press enter to continue...')
    os.system('pip install bs4 requests')

import requests
from bs4 import BeautifulSoup,  NavigableString

class col:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    VIOLET = '\033[95m'   # Bright Magenta (closest)
    INDIGO = '\033[94m'   # Bright Blue
    BLUE   = '\033[34m'   # Standard Blue
    GREEN  = '\033[32m'   # Standard Green
    YELLOW = '\033[33m'   # Standard Yellow
    ORANGE = '\033[91m'   # Bright Red (closest ANSI match to orange)
    RED    = '\033[31m'   # Standard Red


def delete_json_files_in_temp():
    folder = './temp'
    if not os.path.exists(folder):
        return

    for filename in os.listdir(folder):
        if filename.endswith('.json'):
            file_path = os.path.join(folder, filename)
            try:
                os.chmod(file_path, stat.S_IWRITE)
                os.remove(file_path)
            except Exception as e:
                return


def delete_main_file(file : str):
    folder = f'./in/{file}'

    if os.path.isfile(folder) :
        try:
                os.chmod(folder, stat.S_IWRITE)
                os.remove(folder)
        except Exception as e:
                return

files_to_rebuild : list[str] = []
total : int = 0
inside : int = 0
out : str = ''
precent : str = ''
if not os.path.isfile('./passed.txt') :
    f = open('./passed.txt', 'w')
    f.close()


def is_data_inside(key : str) :
    dts : list[str] = []
    f = open('./passed.txt', 'r')
    dts = [str(t).strip() for t in f.readlines()]
    return key in dts


def save(key, value, file) :
    with open(file, 'w', encoding='utf-8') as f :
        json.dump({key : value}, f)
    with open('./passed.txt', 'a') as f :
        f.write(f'{key}\n')
    
def rebuild_data(out : str) :
    data : dict = dict()
    ct = 0
    ln = len(files_to_rebuild)
    for file in files_to_rebuild :
        print (f'[Rebuilding Data] {round(ct / ln * 100, 1)}%...')
        with open(file, 'r', encoding='utf-8') as f :
            data = data | dict(json.load(f))
        ct = ct + 1
        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')
        sys.stdout.flush()
    print (data)
    input()
    with open(out, 'w', encoding='utf-8') as f :
        json.dump(data, fp=f)
    print (f'[Rebuilding Complete] 100%...')
    delete_json_files_in_temp()
    files_to_rebuild.clear()


def for_direct_stemmas(url : str) -> dict:
    parser = requests.get(url)

    soup = BeautifulSoup(parser.text, 'html.parser')
    padleft_div = soup.find('div', class_='padleft')



    content = {}
    current_key = None
    current_text = []

    for elem in padleft_div.descendants:
        if isinstance(elem, NavigableString):
            if current_key:
                current_text.append(str(elem).strip())
        elif elem.name in ['b', 'div'] and elem.get('class') == ['vheading2']:
            if current_key and current_text:
                # Save the previous section
                content[current_key] = ' '.join(current_text).strip()
            current_key = elem.get_text(strip=True)
            current_text = []
        elif elem.name == 'b':
            if current_key and current_text:
                content[current_key] = ' '.join(current_text).strip()
            current_key = elem.get_text(strip=True)
            current_text = []

    # Add the last collected block
    if current_key and current_text:
        content[current_key] = ' '.join(current_text).strip()

    content = {k: v for k, v in content.items() if v}
    return content


folder_path = './in'
temp_path = '/temp'
json_files = [f for f in os.listdir(folder_path) if f.endswith('.json')]


out = None
for file in json_files :
    count   : int = 0
    inside  : int = 0
    precent : int = 0
    path = f'{folder_path}/{file}'
    out = f'./out/{file}'
    links : dict = json.load(fp=open(path, 'r'))
    total = len(links)
    for title, link in links.items() :
        inside = inside + 1
        t_file = f'./temp/{inside}.json'
        print(f'{col.BLUE}[~]{col.ENDC} Working for : {col.YELLOW}{file}{col.ENDC} {col.GREEN}{precent}%{col.ENDC} | ({col.OKCYAN}{inside}{col.ENDC}/{total}) - [{col.ORANGE}{title}{col.ENDC}]')
        if not is_data_inside(title) :
            precent = f'{round(inside / total * 100, 3)}'
            save(key=title, value=for_direct_stemmas(link), file=t_file)
        else :
            precent = f'{round(inside / total * 100, 3)}'
            print(f'Skipping {title}, because it already exsists...')
        os.system('cls' if os.name == 'nt' else 'clear')
        files_to_rebuild.append(t_file)
    try :
        rebuild_data(out=out)
        delete_main_file(file)
        os.system('cls' if os.name == 'nt' else 'clear')
    except :
        pass